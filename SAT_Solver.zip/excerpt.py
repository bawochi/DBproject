from __future__ import division
from __future__ import print_function

from collections import deque
from sys import stderr




def dump_excerpt(example, excerpt):
    print('Current excerpt:', file=stderr)
    for l, w in enumerate(excerpt):
        literal_string = example.literal_to_string(l)
        clauses_string = ', '.join(example.clause_to_string(c) for c in w)
        print('{}: {}'.format(literal_string, clauses_string), file=stderr)


def setup_excerpt(example):
    excerpt = [deque() for __ in range(2 * len(example.variables))]
    for clause in example.clauses:
        # Make the clause watch its first literal
        excerpt[clause[0]].append(clause)
    return excerpt


def update_excerpt(example,
                     excerpt,
                     false_literal,
                     assignment,
                     meow):

    while excerpt[false_literal]:
        clause = excerpt[false_literal][0]
        found_alternative = False
        for alternative in clause:
            v = alternative >> 1
            a = alternative & 1
            if assignment[v] is None or assignment[v] == a ^ 1:
                found_alternative = True
                del excerpt[false_literal][0]
                excerpt[alternative].append(clause)
                break

        if not found_alternative:
            if meow:
                dump_excerpt(example, excerpt)
                print('Current assignment: {}'.format(
                      example.assignment_to_string(assignment)),
                      file=stderr)
                print('Clause {} contradicted.'.format(
                      example.clause_to_string(clause)),
                      file=stderr)
            return False
    return True
