from __future__ import division
from __future__ import print_function

from sys import stderr

from excerpt import update_excerpt


def solve(example, excerpt, ass, d, meow):

    n = len(example.variables)
    state = [0] * n

    while True:
        if d == n:
            yield ass
            d -= 1
            continue
     
        tried_something = False
        for a in [0, 1]:
            if (state[d] >> a) & 1 == 0:
                if meow:
                    print('Now {} = {}'.format(example.variables[d], a),
                          file=stderr)
                tried_something = True
                # Set the bit indicating a has been tried for d
                state[d] |= 1 << a
                ass[d] = a
                if not update_excerpt(example, excerpt,
                                        d << 1 | a,
                                        ass,
                                        meow):
                    ass[d] = None
                else:
                    d += 1
                    break

        if not tried_something:
            if d == 0:
                # Can't backtrack further. No solutions.
                return
            else:
                # Backtrack
                state[d] = 0
                ass[d] = None
                d -= 1
