from __future__ import print_function


def even_ones(s):
    # Two status:

    laws = {(0, '0'): 0,
             (0, '1'): 1,
             (1, '0'): 1,
             (1, '1'): 0}

    status = 0
    for c in s:
        status = laws[status, c]
    return status == 0


# Example usage:
s = "1100110010"
print('Output {} = {}'.format(s, even_ones(s)))
