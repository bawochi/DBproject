from __future__ import division
from __future__ import print_function

from sys import stderr

from excerpt import update_excerpt


def solve(example, excerpt, ass, d, meow):
    
    if d == len(example.variables):
        yield ass
        return

    for a in [0, 1]:
        if meow:
            print('Now {} = {}'.format(example.variables[d], a),
                  file=stderr)
        ass[d] = a
        if update_excerpt(example,
                            excerpt,
                            (d << 1) | a,
                            ass,
                            meow):
            for a in solve(example, excerpt, ass, d + 1, meow):
                yield a

    ass[d] = None
