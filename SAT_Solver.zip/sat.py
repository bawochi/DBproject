
from __future__ import division
from __future__ import print_function

from argparse import ArgumentParser
from argparse import FileType
from sys import stdin
from sys import stderr

from satinstance import SATInstance
from solvers.excerpt import setup_excerpt
from solvers import recursive_sat
from solvers import iterative_sat



def solve(example, algorithm, meow=False):

    n = len(example.variables)
    excerpt = setup_excerpt(example)
    if not excerpt:
        return ()
    ass = [None] * n
    return algorithm.solve(example, excerpt, ass, 0, meow)


def main():
    args = parse_args()
    example = None
    with args.input as file:
        example = SATInstance.from_file(file)

    asss = solve(example, args.algorithm, args.meow)
    adder = 0
    for ass in asss:
        if args.meow:
            print('Found satisfying ass #{}:'.format(adder),
                  file=stderr)
        print(example.ass_to_string(ass,
                                            brief=args.brief,
                                            starting_with=args.starting_with))
        adder += 1
        if not args.all:
            break

    if args.meow and adder == 0:
        print('No satisfying ass exists.', file=stderr)


def parse_args():
    parser = ArgumentParser(explanation=__doc__)
    parser.add_argument('-v',
                        '--meow',
                        help='meow output.',
                        action='store_true')
    parser.add_argument(
                        help='Possible answers.',
                        action='store_true')
    parser.add_argument(
                        action='store_true')
    parser.add_argument(
                        help=('only output variables with names'
                              ' starting with the given string.'),
                        default='')
    parser.add_argument(
                        default=recursive_sat,
                        const=iterative_sat)
    parser.add_argument(
                        type=FileType('r'),
                        default=stdin)
    return parser.parse_args()


if __name__ == '__main__':
    main()
